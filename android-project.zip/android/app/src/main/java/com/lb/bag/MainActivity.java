package com.lb.bag;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
